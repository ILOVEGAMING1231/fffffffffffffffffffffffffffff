## Similar Projects

### Paperclips  
http://www.decisionproblem.com/paperclips/index2.html  
Inspired this project

### Rescue Satoshi
https://zck.me/bitcoin-clicker/  
It seems sb. had a very similar idea ;-)

### Tap Tap Mine
https://www.crazygames.com/game/bitcoin-tap-tap-mine


## Resources used during development

### HTML Meta Tags
Schema.org  
https://schema.org/Game

JSON-LD Generator  
https://www.schemaapp.com/tools/jsonld-schema-generator/Game/

Meta Tag Generator
https://megatags.co/  

Some documentation on meta tags
https://css-tricks.com/essential-meta-tags-social-media/  

## Audio

Probably a good choice for audio support
https://github.com/IonDen/ion.sound

## GIF

Online video to gif converter
https://ezgif.com
